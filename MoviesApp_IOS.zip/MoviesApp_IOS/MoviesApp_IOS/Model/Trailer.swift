//
//  Trailer.swift
//  MoviesApp_IOS
//
//  Created by Esraa Hassan on 5/24/19.
//  Copyright © 2019 iti. All rights reserved.
//

import Foundation
class Trailer{
    var trailerName: String
    var key :String
    
    init(trailerName : String , key : String) {
        self.trailerName=trailerName
        self.key=key
    }
}
