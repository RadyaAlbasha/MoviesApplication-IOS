//
//  HomeDelegate.swift
//  MoviesApp_IOS
//
//  Created by Esraa Hassan on 5/18/19.
//  Copyright © 2019 iti. All rights reserved.
//

import Foundation
import UIKit
protocol HomeDelegate {
    func setMoviesArr(moviesArr : Array<HomeMovie>)
    func showInternetConnectionAlert()
    //func showMovieDetails(segueDestination : String)
   // func showMovieDetails()
    // func downloadImage(imageView : UIImageView)
    
    
}
